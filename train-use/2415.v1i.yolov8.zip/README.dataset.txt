# 2415 > 2024-01-05 3:45pm
https://universe.roboflow.com/test-viune/2415

Provided by a Roboflow user
License: CC BY 4.0

